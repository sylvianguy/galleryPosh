# Harp, Gulp And BrowserSync

A ready-to-go Gulp and Harp set up that does auto css injection via BrowserSync.

You can set it via Harp with:

```console
harp init src --boilerplate superhighfives/harp-gulp-browsersync-boilerplate
```

Then, success.
